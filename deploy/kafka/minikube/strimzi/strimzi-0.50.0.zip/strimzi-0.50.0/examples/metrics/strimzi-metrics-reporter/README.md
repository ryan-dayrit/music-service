# Metrics configuration examples

The examples in this directory demonstrate how you can use configure metrics with Strimzi Metrics Reporter plugin.
There are also some Grafana dashboards that you can use with them.